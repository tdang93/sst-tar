var classSST_1_1Core_1_1Serialization_1_1serialize_3_01std_1_1list_3_01T_01_4_01_4 =
[
    [ "operator()", "classSST_1_1Core_1_1Serialization_1_1serialize_3_01std_1_1list_3_01T_01_4_01_4.html#a530a11b2246d1c317c902416f6073558", null ]
];
var classSST_1_1SharedRegionImpl =
[
    [ "SharedRegionImpl", "classSST_1_1SharedRegionImpl.html#a6d3e33df3c11a1f136b5c3e0a06ed00a", null ],
    [ "getRegion", "classSST_1_1SharedRegionImpl.html#aa25e624d5e3d7655e36fef261abf425b", null ],
    [ "isPublished", "classSST_1_1SharedRegionImpl.html#ac556cb4c6e50163b4ef97f9eb8e620c2", null ],
    [ "setPublished", "classSST_1_1SharedRegionImpl.html#a433abd59c4c9318a5cead7478b21a405", null ]
];
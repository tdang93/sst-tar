var classsprockit_1_1serializable__ptr__type =
[
    [ "ptr", "classsprockit_1_1serializable__ptr__type.html#a28b84592e680fb7769eb2374d3888168", null ]
];
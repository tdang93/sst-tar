var structSST_1_1sstLongOpts__s =
[
    [ "argFunc", "structSST_1_1sstLongOpts__s.html#a79cf79dbd1e39e2d1d2c5a1e2a6d2244", null ],
    [ "argName", "structSST_1_1sstLongOpts__s.html#a70fb310bf678b92fa1ebf0068fa8efa8", null ],
    [ "desc", "structSST_1_1sstLongOpts__s.html#ab860e5f08c18dd46765c36abfdeae890", null ],
    [ "flagFunc", "structSST_1_1sstLongOpts__s.html#a9b3ab24f62a0b3078f9d8794fe4f5a7e", null ],
    [ "opt", "structSST_1_1sstLongOpts__s.html#a9fcdb6b18d8936acb08d11b54b6ebf12", null ]
];
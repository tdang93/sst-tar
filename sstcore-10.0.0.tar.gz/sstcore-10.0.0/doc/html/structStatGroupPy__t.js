var structStatGroupPy__t =
[
    [ "ptr", "structStatGroupPy__t.html#a8ba51a4a62ab09ae5fd2a0824cc50255", null ]
];
var structStatOutputPy__t =
[
    [ "id", "structStatOutputPy__t.html#aa295bd56f2bcfe5aaaa17439649e559a", null ],
    [ "ptr", "structStatOutputPy__t.html#a869b946934b4e2e9629ff99790f51742", null ]
];
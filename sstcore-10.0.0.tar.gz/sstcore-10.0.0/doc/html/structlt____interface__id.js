var structlt____interface__id =
[
    [ "id_string", "structlt____interface__id.html#a988dad0983a063fd2c378a2f8f32189a", null ],
    [ "iface", "structlt____interface__id.html#ae34a491d1dcdd2829dff51c67cac4291", null ]
];
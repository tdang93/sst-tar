var structlt__interface__data =
[
    [ "data", "structlt__interface__data.html#abae3d4b410779998b2a23fc85accc6f6", null ],
    [ "key", "structlt__interface__data.html#a6bed2e2f1888ca34d1c8f5bb03dedf99", null ]
];